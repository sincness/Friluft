import React, { Component } from 'react';
import './customers.css';

class Customers extends Component {
  render() {
    return (
      <div>
        <h2>Customers</h2>
        <ul>
        </ul>
      </div>
    );
  }
}

export default Customers;
